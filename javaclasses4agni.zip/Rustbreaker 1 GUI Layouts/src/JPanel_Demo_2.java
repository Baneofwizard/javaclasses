/**
 * Program Name: JPanel_Demo_2.java <br>
 * Purpose: shows the use of several JPanels as sub-containers within a JFrame.
 *          REVISION: here we apply a different layout manager to the panels and then add
 *          some components to each one
 * @author Bill Pulling
 * Date: Mar 4, 2022
 */
//The Three Wise Men (three imports seen in just about every GUI app done in Java)
import java.awt.*; //the ORIGINAL Java GUI package library
import java.awt.event.*; //for handling EVENT objects created by users interacting with components
import javax.swing.*; // the GREAT LEAP FORWARD...the big GUI upgrade done in JDK 1.2

@SuppressWarnings({ "unused", "serial" })
public class JPanel_Demo_2 extends JFrame
{
   //constructor
	JPanel_Demo_2()
	{
		//pass up the title to JFrame constructor
		super("Demonstration of JPanel Usage");
		
		//BOILERPLATE
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);//destroy this object when close button is pressed
		this.setSize(500, 500); //width and height in pixels
		this.setLocationRelativeTo(null);//centres the JFrame on the screen.
		this.setLayout(new GridLayout(2,2));//2 rows, 2 columns, no visible gaps between elements
		
		//For pnl1, we won't set a layout manager. Instead, we will go with its DEFAULT LAYOUT of FlowLayout
		JPanel pnl1 = new JPanel();
		this.add(pnl1);
		//components for pnl1 will be four JButtons
		JButton btn1 = new JButton("1");
		pnl1.add(btn1);
		JButton btn2 = new JButton("2");
		pnl1.add(btn2);
		JButton btn3 = new JButton("3");
		pnl1.add(btn3);
		JButton btn4 = new JButton("4");
		pnl1.add(btn4);
		
			
		JPanel pnl2 = new JPanel();
		//for pnl2 we'll set it to a GridLayout with hGap and vGap set to 50
		pnl2.setLayout(new GridLayout(2,2,50,50));
		//components for pnl1 will be four more JButtons
		JButton btn5 = new JButton("5");
		pnl2.add(btn5);
		JButton btn6 = new JButton("6");
		pnl2.add(btn6);
		JButton btn7 = new JButton("7");
		pnl2.add(btn7);
		JButton btn8 = new JButton("8");
		pnl2.add(btn8);		
		this.add(pnl2);
		//change the background color of pnl2 to green
		pnl2.setBackground(Color.GREEN);
		
		//for pnl3 we'll set it to BorderLayout and add some JLabels
		JPanel pnl3 = new JPanel();
		pnl3.setLayout(new BorderLayout());
		this.add(pnl3);
		//add some JLabels
		JLabel centerLbl = new JLabel("Center Zone");
		pnl3.add(centerLbl, BorderLayout.CENTER);
		JLabel northLbl = new JLabel("NORTH Zone");
		pnl3.add(northLbl, BorderLayout.NORTH);
		JLabel southLbl = new JLabel("SOUTH Zone");
		pnl3.add(southLbl, BorderLayout.SOUTH);
		pnl3.setBackground(Color.YELLOW);	
		
		
		//set pnl4 to BorderLayout as well
		
		JPanel pnl4 = new JPanel();
		pnl4.setLayout(new BorderLayout());
		//add a JLabel to North and a JTextArea to CENTER and a JButton to south
		JLabel lblNorth = new JLabel("Enter some text in the JTextArea below:");
		pnl4.add(lblNorth,BorderLayout.NORTH);
		JTextArea txtArea = new JTextArea(10,10);//10 rows and 10 columns for text entry
		pnl4.add(txtArea, BorderLayout.CENTER);
		JButton sendBtn = new JButton("Send text...");
		pnl4.add(sendBtn, BorderLayout.SOUTH);
		this.add(pnl4);
		pnl4.setBackground(Color.CYAN);
		
		//THE LAST LINE!
		this.setVisible(true);
	}//end constructor
	
	
	public static void main(String[] args)
	{
     //do an ANONYMOUS object to start the app
		new JPanel_Demo_2();
	}
	//end main
}
//end class