/**
 * Program Name: MyFirstFrame.java
 * Purpose: shows how to create a top level container called a jframe to
 * 				  create this our class has to extend from the jframe class
 * @author: Kieran Primeau 0989303
 * Date: Jun. 29, 2022
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
@SuppressWarnings({ "serial", "unused" })

public class MyFirstFrame extends JFrame
{
	//class data members if any would go here
	
	//override the construct of the JFrame class
	public MyFirstFrame()
	{
		//call super and pass up the title bar text
		super("This is our first JFrame app...");
	
	//BOILER PLATE CODE: we see these lines in almost all GUI APPs as "set up code"
	this.setDefaultCloseOperation(EXIT_ON_CLOSE); //object destroyed when close
	this.setSize(400, 600); //sets size, width height
	this.setLocationRelativeTo(null); //easy way to center frame in screen
	this.setLayout(new BorderLayout() );//sets new border layout, using anon object here
	
	//this is where we would add components
	
	//LAST LINES
	//this.pack();//if used this line will minimize the space taken by the JFrame
	this.setVisible(true);//ALL JFames are, by default invisible
	
	
	}//end constructor
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		//create either a named or anon obj
		//using a named object
		//MyFirstFrame frame = new MyFirstFrame();
		//done anon
		new MyFirstFrame();
	}
	//end main
}
//End class