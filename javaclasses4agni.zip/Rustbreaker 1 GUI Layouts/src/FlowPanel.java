/**
 * Program Name: FlowPanel.java
 * Purpose: uses a FlowLayout for this panel.
 * Used in Layout_Demo_Using_JTabbedPane
 * Coder: Bill Pulling for Section 01
 * Date: March 12, 2021
 */

import javax.swing.*;
import java.awt.*;
@SuppressWarnings("serial")
public class FlowPanel extends JPanel
{
	//constructor
	FlowPanel()
	{
		super();//courtesy call
		//set up
		this.setBackground(Color.RED);
		this.setLayout(new FlowLayout() );//ANONYMOUS OBJECT AGAIN!
		//NOTE: default layout for JPanel is actually the FlowLayout.
		//five buttons
		JButton btn1 = new JButton("1");
		JButton btn2 = new JButton("2");
		JButton btn3 = new JButton("3");
		JButton btn4 = new JButton("4");
		JButton btn5 = new JButton("5");
		
		//add them to container
		this.add(btn1);
		this.add(btn2);
		this.add(btn3);
		this.add(btn4);
		this.add(btn5);
		
	}//end constructor
}
//end class