/**
 * Program Name: My_Second_Frame.java <br>
 * Purpose: In this version we add some COMPONENT OBJECTS to the CONTAINER. Here we will add some 
 *          JButtons to the BorderLayout zones of NORTH, SOUTH, EAST, WEST,AND CENTER 
 * @author Kieran Pimeau
 * Date: June 29, 2022
 */

//The Three Wise Men (three imports seen in just about every GUI app done in Java)
import java.awt.*; //the ORIGINAL Java GUI package library
import java.awt.event.*; //for handling EVENT objects created by users interacting with components
import javax.swing.*; // the GREAT LEAP FORWARD...the big GUI upgrade done in JDK 1.2
@SuppressWarnings({ "serial", "unused" })

public class My_Second_Frame extends JFrame
{
	
	//class data members, if any, would normally be put here.
	
	//constructor override
	public My_Second_Frame()
	{
		super("This is our Second JFrame App With JButtons");
		
		//BOILER PLATE CODE..this is standard code seen in almost all JFrame sub classes to set things up
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);//destroy this object when close button is pressed
		this.setSize(450, 400); //width and height in pixels
		this.setLocationRelativeTo(null);//centres the JFrame on the screen.
		this.setLayout(new BorderLayout());//sets this screen to use a BorderLayout for its components
		                                  //NOTE: BorderLayout is actually the DEFAULT layout for a JFrame
		//NOTE #2: we are creating an ANONYMOUS OBJECT here. We did not specify a variable name for the 
		// BorderLayout object. Java compiler assigns an internal identifier to this object.
		
		//down here is where we would add our components to the JFrame container.
		//Step 1: create the component
		JButton btn1 = new JButton("Push me!");
		//Step 2: add it to the container
		this.add(btn1, BorderLayout.CENTER);
		
		//continuation on Fri March 4
		//create some more JButtons
		JButton btn2 = new JButton("No, push me instead");
		//put this one in the SOUTH zone
		this.add(btn2, BorderLayout.SOUTH);
		//add a few more...
		JButton btn3 = new JButton("Ignore the others, push me!");
		this.add(btn3, BorderLayout.NORTH);
		
		JButton btn4 = new JButton("Button 4");
		this.add(btn4, BorderLayout.WEST);
		
		JButton btn5 = new JButton("Button 5");
		this.add(btn5, BorderLayout.EAST);
	
		//THE LAST LINE!
		this.setVisible(true);// BY DEFAULT, the visibility of a JFrame is set to false. To make it appear
		                      // on the screen, we have to put this in as THE LAST LINE in the constructor.
	}//end constructor
	
	public static void main(String[] args)
	{
    //create an object of the class. THIS IS ALSO COMMONLY DONE AS AN ANONYMOUS OBJECT
		//FIRST WAY: we'll actually DECLARE an object variable for our JFrame object
		//My_First_Frame frame1 = new My_First_Frame();
		
		//SECOND WAY: done ANONOMOUSLY
		new My_Second_Frame();
	}
	//end main
}
//end class