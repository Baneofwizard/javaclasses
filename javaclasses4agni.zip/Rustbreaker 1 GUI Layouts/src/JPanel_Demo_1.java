/**
 * Program Name: JPanel_Demo_1.java <br>
 * Purpose: shows the use of several JPanels as sub-containers within a JFrame. 
 * @author Bill Pulling
 * Date: Mar 4, 2022
 */
//The Three Wise Men (three imports seen in just about every GUI app done in Java)
import java.awt.*; //the ORIGINAL Java GUI package library
import java.awt.event.*; //for handling EVENT objects created by users interacting with components
import javax.swing.*; // the GREAT LEAP FORWARD...the big GUI upgrade done in JDK 1.2

@SuppressWarnings({ "serial", "unused" })
public class JPanel_Demo_1 extends JFrame
{
   //constructor
	JPanel_Demo_1()
	{
		//pass up the title to JFrame constructor
		super("Demonstration of JPanel Usage");
		
		//BOILERPLATE
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);//destroy this object when close button is pressed
		this.setSize(500, 500); //width and height in pixels
		this.setLocationRelativeTo(null);//centres the JFrame on the screen.
		this.setLayout(new GridLayout(2,2));//2 rows, 2 columns, no visible gaps between elements
		
		//create 4 JPanels and add them to the JFrame. REMEMBER that JPanels have no title bar and no borders.
		JPanel pnl1 = new JPanel();
		this.add(pnl1);
	
		JPanel pnl2 = new JPanel();
		this.add(pnl2);
		//change the background color of pnl2 to green
		pnl2.setBackground(Color.GREEN);
		JPanel pnl3 = new JPanel();
		this.add(pnl3);
		pnl3.setBackground(Color.BLUE);		
		JPanel pnl4 = new JPanel();
		this.add(pnl4);
		pnl4.setBackground(Color.CYAN);	
		
		//THE LAST LINE!
		this.setVisible(true);
	}//end constructor
	
	public static void main(String[] args)
	{
     //do an ANONYMOUS object to start the app
		new JPanel_Demo_1();
	}
	//end main
}//end class