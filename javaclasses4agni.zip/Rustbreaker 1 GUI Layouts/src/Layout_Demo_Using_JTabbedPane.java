/**
 * Program Name: Layout_Demo_Using_JTabbedPane.java
 * Purpose: this is the DRIVER class that actually creates the JFrame that will hold
 *          the various JPanels inside of a JTabbedPane container.
 * Coder: Bill Pulling for Section 01
 * Date: March 4, 2022
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
@SuppressWarnings("unused")
public class Layout_Demo_Using_JTabbedPane
{
	public static void main(String[] args)
	{
		// build the JFrame here in the main 
		JFrame frame = new JFrame("Layout Manager Demonstration");
		
		//boilerplate
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(600,300);
		frame.setLocationRelativeTo(null);
		
		//create a JTabbedPane object
		JTabbedPane tPane = new JTabbedPane();
		
		//now call the JPanel constructor classes and add each one to the JTabbedPane.
		// First parameter is the text that appears on the tab, second parameter is
		// the component being added to the tab. In this case it is a JPanel
		tPane.add("Introduction", new IntroPanel() );
		
		//add the second panel for BorderLayout
		tPane.add("Border Layout Example", new BorderPanel() );//another use of an ANONYMOUS OBJECT
		
		//add the third panel showing GridLayout
		tPane.add("GridLayout Example", new GridPanel() );
		
		//add fourth panel showing FlowLayout
		tPane.add("FlowLayout Example", new FlowPanel() );
		
		//add fifth panel showing vertical BoxLayout
		tPane.add("Vertical BoxLayout Example", new VerticalBoxPanel() );
		
		//add sixth panel showing horizontal BoxLayout
		tPane.add("Horizontal BoxLayout Example", new HorizontalBoxPanel() );
		
		//add the JTabbedPane to the JFrame
		frame.add(tPane);
		
		//last line
		frame.setVisible(true);		
	}	//end main
}//end class