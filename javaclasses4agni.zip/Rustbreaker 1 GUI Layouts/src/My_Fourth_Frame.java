/**
 * Program Name: My_Fourth_Frame.java <br>
 * Purpose: In this version we just change the layout manager to a GRID LAYOUT. 
 * @author Bill Pulling
 * Date: Mar 3, 2022
 */

//The Three Wise Men (three imports seen in just about every GUI app done in Java)
import java.awt.*; //the ORIGINAL Java GUI package library
import java.awt.event.*; //for handling EVENT objects created by users interacting with components
import javax.swing.*; // the GREAT LEAP FORWARD...the big GUI upgrade done in JDK 1.2
@SuppressWarnings({ "serial", "unused" })

public class My_Fourth_Frame extends JFrame
{
	
	//class data members, if any, would normally be put here.
	
	//constructor override
	public My_Fourth_Frame()
	{
		super("This is our Fourth JFrame App Using Grid Layout");
		
		//BOILER PLATE CODE..this is standard code seen in almost all JFrame sub classes to set things up
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);//destroy this object when close button is pressed
		this.setSize(450, 400); //width and height in pixels
		this.setLocationRelativeTo(null);//centres the JFrame on the screen.
		
		//REVISION HERE: change to GridLayout,where we specify NUMBER OF ROWS and NUMBER OF COLUMNS in 
		//               the grid. 
		
		//GridLayout gridLayout = new GridLayout(3,4);//ROWS BEFORE COLUMNS!
		
		//NOTE: can also use the 4-arg constructor to set a visible gap between components, like this:
		GridLayout gridLayout = new GridLayout(3,4,10,10);//sets a gap of 10 pixels horizontally and vertically
		this.setLayout(gridLayout);//watch how components are arranged.
		//can we adjust the default from center justified to left justified?
		//flowLayout.setAlignment(FlowLayout.LEFT);
		//down here is where we would add our components to the JFrame container.
		//Step 1: create the components
		JButton btn1 = new JButton("Button 1");
		JButton btn2 = new JButton("Button 2");
		JButton btn3 = new JButton("Button 3");
		JButton btn4 = new JButton("Button 4");
		JButton btn5 = new JButton("Button 5");
		JButton btn6 = new JButton("Button 6");
		JButton btn7 = new JButton("Button 7");
		JButton btn8 = new JButton("Button 8");
		JButton btn9 = new JButton("Button 9");
		//Q. What happens if we add a tenth component to a 3 by 3 grid layout? 
		//A> The layout manager will add another column to accommodate the overflow objects.
		JButton btn0 = new JButton("0");
		
		//now add them to the frame
		this.add(btn1);
		this.add(btn2);
		this.add(btn3);
		this.add(btn4);
		this.add(btn5);
		this.add(btn6);
		this.add(btn7);
		this.add(btn8);
		this.add(btn9);
		this.add(btn0);
	
	
		//THE LAST LINE!
		this.setVisible(true);// BY DEFAULT, the visibility of a JFrame is set to false. To make it appear
		                      // on the screen, we have to put this in as THE LAST LINE in the constructor.
	}//end constructor
	
	public static void main(String[] args)
	{
    //create an object of the class. THIS IS ALSO COMMONLY DONE AS AN ANONYMOUS OBJECT
		//FIRST WAY: we'll actually DECLARE an object variable for our JFrame object
		//My_First_Frame frame1 = new My_First_Frame();
		
		//SECOND WAY: done ANONOMOUSLY
		new My_Fourth_Frame();
	}
	//end main
}
//end class