/**
 * Program Name: BorderPanel.java
 * Purpose: uses a GridLayout for this panel.
 * Used in Layout_Demo_Using_JTabbedPane
 * Coder: Bill Pulling for Section 01
 * Date: March 4, 2022
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings({ "unused", "serial" })
public class GridPanel extends JPanel
{
	//constructor
	public GridPanel()
	{
		super();
		
		//set up
		this.setBackground(Color.DARK_GRAY);
		this.setLayout(new GridLayout(2,3,10,10) );
		
		//five JButtons
		JButton btn1 = new JButton("1");
		JButton btn2 = new JButton("2");		
		JButton btn3 = new JButton("3");		
		JButton btn4 = new JButton("4");		
		JButton btn5 = new JButton("5");
		JButton btn6 = new JButton("6");
		
		//add them to the JPanel
		this.add(btn1);
		this.add(btn2);
		this.add(btn3);
		this.add(btn4);
		this.add(btn5);
		this.add(btn6);
				
	}//end constructor
	
}//end class