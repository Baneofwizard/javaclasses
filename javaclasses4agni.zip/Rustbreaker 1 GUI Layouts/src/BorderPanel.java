/**
 * Program Name: BorderPanel.java
 * Purpose: JPanel to hold the BorderLayout example.
 * Used in Layout_Demo_Using_JTabbedPane
 * Coder: Bill Pulling for Section 01
 * Date: March 4, 2022
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

@SuppressWarnings({ "unused", "serial" })
public class BorderPanel extends JPanel
{
	//constructor
	public BorderPanel()
	{
		super();
		
		//set up
		this.setBackground(Color.DARK_GRAY);
		this.setLayout(new BorderLayout() );
		
		//five JButtons
		JButton btn1 = new JButton("1");
		JButton btn2 = new JButton("2");		
		JButton btn3 = new JButton("3");		
		JButton btn4 = new JButton("4");		
		JButton btn5 = new JButton("5");
		
		//add to the JPanel..try just using int values from 1 to 5 to see what happens
		this.add(btn1, BorderLayout.NORTH);
		this.add(btn2, BorderLayout.SOUTH);
		this.add(btn3, BorderLayout.EAST);
		this.add(btn4, BorderLayout.WEST);
		this.add(btn5, BorderLayout.CENTER);
		
	}	
}
//end class