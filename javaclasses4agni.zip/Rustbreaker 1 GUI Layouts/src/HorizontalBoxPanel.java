/**
 * Program Name: HorizontalBoxPanel.java
 * Purpose: uses a horizontally aligned BoxLayout for this panel.
 * Used in Layout_Demo_Using_JTabbedPane
 * Coder: Bill Pulling for Section 01
 * Date: March 4, 2022
 */

import javax.swing.*;
import java.awt.*;
@SuppressWarnings("serial")
public class HorizontalBoxPanel extends JPanel
{
	//constructor
	HorizontalBoxPanel()
	{
		super();//courtesy call
		//set up
		this.setBackground(Color.MAGENTA);
		//set up the box to run HORIZONTALLY along the X_AXIS
		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS) );//ANONYMOUS OBJECT AGAIN!
		
		//five buttons
		JButton btn1 = new JButton("1");
		JButton btn2 = new JButton("2");
		JButton btn3 = new JButton("3");
		JButton btn4 = new JButton("4");
		JButton btn5 = new JButton("5");
		
		//add them to container
		this.add(btn1);
		//add a rigid area 10 pixels WIDE that will stay the same size if user re-sizes
		// the panel
		this.add(Box.createRigidArea(new Dimension(10, 0) ) );
		this.add(btn2);
		
		//add some "HORIZONTAL  glue" between the btn3 and btn 4
		// so that they stick together during re-sizing
		this.add(Box.createHorizontalGlue() );		
		this.add(btn3);
		this.add(btn4);		
		//add one more rigid area of 20 pixels height
		this.add(Box.createRigidArea(new Dimension(20,0) ) );
		
		this.add(btn5);		
	}//end constructor
}//end class