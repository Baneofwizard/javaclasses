/**
 * Program Name: JButton_Listener_Inner_Class_Demo_2.java <br>
 * Purpose: In this version, we write an INNER CLASS inside our our outer class and create an
 *          object of the inner class to act as the NANNY or LISTENER OBJECT.
 * @author Bill Pulling
 * Date: Mar 10, 2022
 */
//The Three Wise Men (three imports seen in just about every GUI app done in Java)
import java.awt.*; //the ORIGINAL Java GUI package library
import java.awt.event.*; //for handling EVENT objects created by users interacting with components
import javax.swing.*; // the GREAT LEAP FORWARD...the big GUI upgrade done in JDK 1.2

@SuppressWarnings("serial")
public class JButton_Listener_Inner_Class_Demo_2 extends JFrame

{
	//CLASS WIDE SCOPE AREA
	JLabel instructLbl; //this will be visible in both constructor method and actionPerformed() method.
	                    //we will be able to change the font color inside actionPerformed().
	
	//constructor
	public JButton_Listener_Inner_Class_Demo_2()
	{
		//courtesy call to super class constructor to pass up title bar text
		super("Demo of Using an INNER Class Object as the Listener");		
		//BOILER PLATE CODE..this is standard code seen in almost all JFrame sub classes to set things up
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);//destroy this object when close button is pressed
		this.setSize(600, 100); //width and height in pixels
		this.setLocationRelativeTo(null);//centres the JFrame on the screen.
		this.setLayout(new FlowLayout());
		
		//create 5 JButtons with different color labels so that we can change the background color
		JButton redBtn = new JButton("Red");
		JButton blueBtn = new JButton("Blue");
		JButton greenBtn = new JButton("Green");
		JButton blackBtn = new JButton("Black");
		JButton grayBtn = new JButton("Gray");
		
		//add these to the JFrame
		this.add(redBtn);
		this.add(blueBtn);
		this.add(greenBtn);
		this.add(blackBtn);
		this.add(grayBtn);
		
		//add an instruction label. Use the one declared in CLASS WIDE SCOPE
		instructLbl = new JLabel("To change the background color, press a button.");
		this.add(instructLbl);
		
		//VERY IMPORTANT STEP IN EVENT HANDLING! You must REGISTER A LISTENER for each JBUtton. In other
		// words, we have to ASSIGN A NANNY TO EACH CHILD EVENT that may be created. 
		
		//IN THIS EXAMPLE, we need to create an OBJECT OF OUR INNER CLASS to act as the listener
		MaryPoppins nanny  = new MaryPoppins();
	  redBtn.addActionListener(nanny);
	  blueBtn.addActionListener(nanny);
	  greenBtn.addActionListener(nanny);
	  blackBtn.addActionListener(nanny);
	  grayBtn.addActionListener(nanny);		
		
		//LAST LINE!
		this.setVisible(true);
	}//end constructor
	
	//NESTED INNER CLASS GOES HERE
	private class MaryPoppins implements ActionListener
	{
	@Override
		//Here is where we put the code that we want executed when an Event object is created.
		public void actionPerformed(ActionEvent ev)
		{
			//Step 1: we want to change the color of the contentPane object, so first we have to get
			// a reference to it from the JFrame host object.
			Container contentPane = getContentPane();
			
			//Step 2: Now we just need to determine WHICH button was pushed to produce the screaming baby event
			// object. An if-else-if can do this by checking the COMMAND STRING that is the label on each JButton.
			if(ev.getActionCommand().equals("Red"))
			{
				contentPane.setBackground(Color.RED);
			}
			else if(ev.getActionCommand().equals("Blue"))
			{
				contentPane.setBackground(Color.BLUE);
			}
			else if(ev.getActionCommand().equals("Green"))
			{
				contentPane.setBackground(Color.GREEN);
			}
			else if(ev.getActionCommand().equals("Black"))
			{
				contentPane.setBackground(Color.BLACK);
				instructLbl.setForeground(Color.WHITE);
			}
			else if(ev.getActionCommand().equals("Gray"))
			{
				contentPane.setBackground(Color.GRAY);
			}
		}//end actionPerformed()
	}//end inner class
	
	
	/**
	 * This method will: generate the JFrame using an ANONYMOUS OBJECT and start the program. 
	 * @param args
	 */
	public static void main(String[] args)
	{
     //ANONYMOUS OBJECT
		new JButton_Listener_Inner_Class_Demo_2();
	}
	//end main


}
//end class